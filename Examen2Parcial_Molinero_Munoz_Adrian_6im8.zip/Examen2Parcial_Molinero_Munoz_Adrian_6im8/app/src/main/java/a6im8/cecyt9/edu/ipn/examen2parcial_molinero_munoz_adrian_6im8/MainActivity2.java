package a6im8.cecyt9.edu.ipn.examen2parcial_molinero_munoz_adrian_6im8;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

/**
 * Created by Usuario on 31/03/2017.
 */

public class MainActivity2 extends Activity{

    Double numeroReci;
    TextView Letrero;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Letrero = (TextView) findViewById(R.id.Letrero);
        Bundle guardaDatos ;
        guardaDatos = this.getIntent().getExtras();
        numeroReci = guardaDatos.getDouble("Resultado");
        Letrero.setText("Molinero Munoz Jesus Adrian" + "   " + "Cantidad convertida: " + numeroReci.toString());
    }

    public void onClickEnviar(View correo)
    {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, " Resultado del Examen");
        intent.putExtra(Intent.EXTRA_TEXT, "Molinero Muñoz Jesus Adrian, mira el resultado: " + numeroReci );
        intent.putExtra(Intent.EXTRA_EMAIL, new String[] { "eoropezag@ipn.mx"} );
        startActivity(intent);
    }



}
