package a6im8.cecyt9.edu.ipn.examen2parcial_molinero_munoz_adrian_6im8;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Double numero1,numeroResultado;
    EditText cNumero;
    String notifError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cNumero = (EditText) findViewById(R.id.cNumero);
    }

    public void onClickConvertir(View v){
        try{
            Intent intento = new Intent(this,MainActivity2.class);
            Bundle guardar = new Bundle();
            numero1 = Double.parseDouble(cNumero.getText().toString());
            numeroResultado = numero1/15;
            guardar.putDouble("Resultado",numeroResultado);
            intento.putExtras(guardar);
            finish();
            startActivity(intento);
        } catch (Exception exx){
            notifError=String.valueOf(numeroResultado);
            notifError = "Lo sentimos hubo un error";
        }

    }
}
